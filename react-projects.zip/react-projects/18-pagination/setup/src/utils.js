const paginate = () => {}

export default paginate

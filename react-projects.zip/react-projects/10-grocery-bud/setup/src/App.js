import React, { useState, useEffect } from 'react'
import List from './List'
import Alert from './Alert'

function App() {
  return <h2>grocery bud setup</h2>
}

export default App

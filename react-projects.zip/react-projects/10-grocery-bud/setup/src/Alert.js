import React, { useEffect } from 'react'

const Alert = () => {
  return <h2>alert component</h2>
}

export default Alert

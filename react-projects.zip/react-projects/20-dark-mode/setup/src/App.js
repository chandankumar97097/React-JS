import React, { useState, useEffect } from 'react'
import data from './data'
import Article from './Article'

function App() {
  return <h2>dark mode starter</h2>
}

export default App

import React from 'react'
import Navbar from './Navbar'
function App() {
  return (
    <>
      <h2>navbar project setup</h2>
    </>
  )
}

export default App
